#include <iostream>
#include <fstream>
#include <map>
#include <stack>
#include <vector>
#include "support.h"
using namespace std;
int playerwon =0;       //global to count how many times the player won
int player2won =0;      //global to count how many times the player2 won
int dealerwon =0;       //global to count how many times the dealer won
int runnum=1;       //global to count how many times the game ran: hand number

struct card{
    char suit;
    string value;
};


map<string,int> cvalue;
void mapinput(){
//==========INSERT VALUES INTO MAP==========
cvalue.insert(make_pair("A",1));       
cvalue.insert(make_pair("2",2));
cvalue.insert(make_pair("3",3));
cvalue.insert(make_pair("4",4));
cvalue.insert(make_pair("5",5));
cvalue.insert(make_pair("6",6));
cvalue.insert(make_pair("7",7));
cvalue.insert(make_pair("8",8));
cvalue.insert(make_pair("9",9));
cvalue.insert(make_pair("10",10));
cvalue.insert(make_pair("J",10));
cvalue.insert(make_pair("Q",10));
cvalue.insert(make_pair("K",10));
}

ostream& operator<<(ostream &out,card &c){
	return out <<c.suit<<c.value;     //operator to print out the card suite and values
}

void readData(string filename, card* cardsarr, int size){
ifstream fin;
fin.open(filename);
card c;
    for(int i=0; i<size; i++){      //read in suite and value 
        fin>>c.suit>>c.value;
        cardsarr[i] = c;        //fill the array from the file
        }
 fin.close();
}

void readData2(string filename, card* cardsarr, int size){
ifstream fin;
fin.open(filename);
card c;
    for(int i=0; i<size; i++){      //read in suite and value
        fin>>c.suit>>c.value;
        cardsarr[i] = c;        //fill the array from the file
        }

 fin.close();
}

void printArray(card* cardsarr, int size){
    for(int i=0; i<size; i++){
        cout<<cardsarr[i]<<" ";     //print out the values of array
    }
}

void printVector(vector<card> cardsvec)
{
    for (int i = 0; i < cardsvec.size(); i++) {     //loop to print out the values of the vector
        cout << cardsvec[i]<<" ";
    }
}

int scoreHand(vector<card> cardsvec){
    int sum =0;     //variable to continure a summation of different values of a card
    for(int i=0; i<cardsvec.size(); i++){
        sum= sum+ cvalue[cardsvec[i].value];        //summation of the card values
    }
    return sum;
}

 void shuffle(card* cardsarr, int size) {            
        int cardsstruck=0;      //variable to count the amount of cards extracted from original
        card cardsshuffled[size];       //new array to insert the extracted cards into

     for (int i = size - 1; i > 0; i--) { // for loop to shuffle
         int j = randomInRange(0, size-1);      //variable that randomly chooses a value to take out of the array
         cardsshuffled[cardsstruck] = cardsarr[j];      //inserting the extracted card into new array
         cardsarr[j] = cardsarr[i];                     //inserting all values of my original vector into the same vector of random values 
         cardsarr[i] = cardsshuffled[cardsstruck] ;     //inserting the shuffled cards from new array into original array
     }
}
void dealplayer(stack<card> &deck, vector<card> &player, vector<card> &dealer){     //deal 2 cards to player at the beginning of each hand
    player.push_back(deck.top());       //adding value to player vector from deck
    deck.pop();     //removing card from top of deck
    
}

void dealdealer(stack<card> &deck, vector<card> &player, vector<card> &dealer){     //deal 2 cards to dealer at the beginning of each hand
    dealer.push_back(deck.top());       //adding value to player vector from deck
    deck.pop();     //removing card from top of deck
    
}

void dealplayer2(stack<card> &deck, vector<card> &player2, vector<card> &dealer){     //deal 2 cards to dealer at the beginning of each hand
    player2.push_back(deck.top());       //adding value to player vector from deck
    deck.pop();     //removing card from top of deck
    
}
void play(stack<card> &deck, vector<card> &player, vector<card> &dealer){
    dealplayer(deck, player, dealer);       //deal the player
    dealdealer(deck, player, dealer);       //deal the dealer
    dealplayer(deck, player, dealer);       //deal the player
    dealdealer(deck, player, dealer);       //deal the dealer
    while(deck.size()>4){       //while loop for as long as the deck has atleast 4 cards to deal out
    if(scoreHand(player)==21 && scoreHand(dealer)!=21){     //player has 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;        //increment the amount of times the player won
        runnum++;       //increment the amount of hands played
        player.clear();     //clear the hand of the player
        dealer.clear();     //clear the hand of the dealer
        player.push_back(deck.top());               //deal out the cards again for next hand    
        deck.pop();     //remove the top element or card of the deck
        dealer.push_back(deck.top());               //deal out the cards again for next hand
        deck.pop();        
        player.push_back(deck.top());               //deal out the cards again for next hand
        deck.pop();     
        dealer.push_back(deck.top());               //deal out the cards again for next hand
        deck.pop(); 
        continue;       //run through the while loop again from the top
    }

    //below is practically the same code but with different if statements for each case

    if(scoreHand(player)>21 && scoreHand(dealer)<=21){       //player over 21 and dealer is not
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Bust, Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon ++;       //increment the amount of times the dealer won
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(player)>=18){};        //player between 18 and 21... do nothing

    if(scoreHand(player)<=12){      //player has less than 13 so draw until 17 or more
        while(scoreHand(player)<=17 ){
            if(deck.size()==0) break;       //if there are no cards left... end the hand
            player.push_back(deck.top());       //player hits
            deck.pop();
        }
    }

     if(scoreHand(player)>=13 && scoreHand(player)<=17){        //player between 13 and 17
        int hitstand = randomInRange(0,1);      //number generator between 0 and 1 to see if the player will hit or stand
        if(hitstand){
            if(deck.size()==0) break;
            player.push_back(deck.top());
            deck.pop();
        }
    }

    if(scoreHand(dealer)==21){      //dealer has 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)<=21){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Bust, Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(dealer)>=17 && scoreHand(dealer)<=21){};       //dealer is betwen 17 and 21

    if(scoreHand(dealer)<17){       //dealer below 17
        while(scoreHand(dealer)<17 ||scoreHand(dealer)<21){
        if(deck.size()==0) break;
        dealer.push_back(deck.top());
        deck.pop();
        if(scoreHand(dealer)>=21) break;
        }
    }

    if(scoreHand(player)==scoreHand(dealer) && scoreHand(player)!=21 &&scoreHand(player)<21){      //scores are equal but not 21
         cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(player)<=scoreHand(dealer) && scoreHand(player)>21){      //both bust but the player has less... player wins
         cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(dealer)<=scoreHand(player) && scoreHand(dealer)>21){      //scores are equal but not 21
         cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

    if(scoreHand(dealer)<scoreHand(player) && scoreHand(dealer)<21&& scoreHand(player)<21){     //player has higher score than dealer below 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }
    
    if(scoreHand(dealer)>scoreHand(player) && scoreHand(dealer)<21&& scoreHand(player)<21){     //dealer has higher score than player
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop();
        player.push_back(deck.top());       
        deck.pop();
        dealer.push_back(deck.top());       
        deck.pop(); 
        continue;
    }

}
    cout<<"====Deck Empty===Game Over===="<<endl;
    cout<<endl<<endl<<"Player won "<<playerwon<<" hands"<<endl<<"Dealer won "<<dealerwon<<" hands"<<endl;
}

void play2(stack<card> &deck, vector<card> &player, vector<card> &player2, vector<card> &dealer){
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    while(deck.size()>4){
    if(scoreHand(player)==21 && scoreHand(dealer)!=21 && scoreHand(player2)!=21){       //player1 has 21, wins
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(player)!=21 && scoreHand(dealer)!=21 && scoreHand(player2)==21){       //player2 has 21, wins
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player2 Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(player)>21 && scoreHand(dealer)<21 && scoreHand(player2)<21 && scoreHand(dealer)>scoreHand(player2)){       //player1 has 21, wins
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(player2)>21 && scoreHand(dealer)<21 && scoreHand(player)<21 && scoreHand(dealer)>scoreHand(player)){       //player1 has 21, wins
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)>21 && scoreHand(player2)>21 && scoreHand(dealer)>scoreHand(player2) && scoreHand(player)<scoreHand(dealer)){       //player1 has 21, wins
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Players Win!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(player)>21 && scoreHand(player2)>21){       //player over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Players Bust, Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(player)>=18){};        //player between 18 and 21

    if(scoreHand(player2)>=18){};       //player2 between 18 and 21

    if(scoreHand(player)<=12){
        while(scoreHand(player)<=17 ){
            if(deck.size()==0) break;
            player.push_back(deck.top());
            deck.pop();
        }
    }

    if(scoreHand(player2)<=12){
        while(scoreHand(player2)<=17 ){
            if(deck.size()==0) break;
            player2.push_back(deck.top());
            deck.pop();
        }
    }

     if(scoreHand(player)>=13 && scoreHand(player)<=17){        //player between 13 and 17
        int hitstand = randomInRange(0,1);
        if(hitstand){
            if(deck.size()==0) break;
            player.push_back(deck.top());
            deck.pop();
        }
    }

    if(scoreHand(player2)>=13 && scoreHand(player2)<=17){        //player2 between 13 and 17
        int hitstand = randomInRange(0,1);
        if(hitstand){
            if(deck.size()==0) break;
            player2.push_back(deck.top());
            deck.pop();
        }
    }

    if(scoreHand(dealer)==21){      //dealer has 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)<=21 && scoreHand(player2)<=21){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Bust, Players Win!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon ++;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)>21 && scoreHand(player2)<=21){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player2 Win!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)<=21 && scoreHand(player2)>21){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Players Win!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)<=21 && scoreHand(player2)>21 && scoreHand(player)<scoreHand(dealer)){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player)<=21 && scoreHand(player2)>21 && scoreHand(player)>scoreHand(dealer)){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player2)<=21 && scoreHand(player)>21 && scoreHand(player2)<scoreHand(dealer)){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>21 && scoreHand(player2)<=21 && scoreHand(player)>21 && scoreHand(player2)>scoreHand(dealer)){       //dealer over 21
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player2 Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon ++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>=17 && scoreHand(dealer)<=21){};       //dealer is betwen 17 and 21

    if(scoreHand(dealer)<17){       //dealer below 17       //FIX THIS STATEMENT
        while(scoreHand(dealer)<17){
        if(deck.size()==0) break;
        dealer.push_back(deck.top());
        deck.pop();
        if(scoreHand(dealer)>=21) break;
        }
    }

    if(scoreHand(player)==scoreHand(dealer)==scoreHand(player2) && scoreHand(player)!=21 &&scoreHand(player)<21){      //scores are equal but not 21
         cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Players Win!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }
    if(scoreHand(dealer)<scoreHand(player)<scoreHand(player2) && scoreHand(dealer)<21&& scoreHand(player)<21&&scoreHand(player2)<21){     //player has higher score than dealer
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player2 Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        player2won++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)<scoreHand(player2)<scoreHand(player) && scoreHand(dealer)<21&& scoreHand(player)<21&&scoreHand(player2)<21){     //player has higher score than dealer
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)<scoreHand(player2)<scoreHand(player) && scoreHand(dealer)<21&& scoreHand(player)<21&&scoreHand(player2)>21){     //player has higher score than dealer
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Player Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        playerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>scoreHand(player2)>=scoreHand(player) && scoreHand(dealer)<21&& scoreHand(player)<21&&scoreHand(player2)<21){     //player has higher score than dealer
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

    if(scoreHand(dealer)>scoreHand(player)>=scoreHand(player2) && scoreHand(dealer)<21&& scoreHand(player)<21&&scoreHand(player2)<21){     //player has higher score than dealer
        cout<<"=Start Hand "<<runnum<<"======================"<<endl;
        cout<<"=Player=============="<<endl;
        printVector(player);
        cout<<" --> "<<scoreHand(player)<<endl;
        cout<<"=Player2=============="<<endl;
        printVector(player2);
        cout<<" --> "<<scoreHand(player2)<<endl;
        cout<<"=Dealer=============="<<endl;
        printVector(dealer);
        cout<<" --> "<<scoreHand(dealer)<<endl;
        cout<<"Dealer Wins!!"<<endl;    
        cout<<"=End Hand "<<runnum<<"======================"<<endl<<endl;
        dealerwon++;
        runnum++;
        player.clear();
        dealer.clear();
        player2.clear();
        dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);       
    dealdealer(deck, player, dealer);
    dealplayer(deck, player, dealer);
    dealplayer2(deck, player2, dealer);
    dealdealer(deck, player, dealer);
    continue;
    }

}
    cout<<"====Deck Empty===Game Over===="<<endl;
    cout<<endl<<endl<<"Player 1 won "<<playerwon<<" hands"<<endl<<"Player 2 won "<<player2won<<" hands"<<endl<<"Dealer won "<<dealerwon<<" hands"<<endl;
}

int main(){
    srandomdev();
    mapinput();     //function to input all the values in a deck into the map
    stack<card> deck;       //stack of cards
    vector<card> player;        //player vector
    vector<card> player2;       //player2 vector
    vector<card> dealer;        //dealer vector
    vector<card> cardsvec;      //cards vector
    //==========SIZE OF ARRAY==========
    //int size =52;

    //==========SIZE OF ARRAY FOR PLAY2==========
    int size =52*5;
    
    //==========ARRAY==========
    //card cardsarr[52];      
    
    //==========ARRAY FOR PLAY2==========
    card cardsarr[52*5];      

    //==========READ DATA==========
    //readData("cards.txt", cardsarr, 52);

    //==========READ FILE FOR PLAY2==========
    readData2("cards2.txt", cardsarr, 52*5);

    //==========SHUFFLE==========
    //shuffle(cardsarr, 52);        //fisher yates algorithm

    //==========SHUFFLE2==========
    shuffle(cardsarr, 52*5);        //fisher yates algorithm

    //==========FILL DECK FROM ARRAY==========
    for(int i=0; i<size; i++) deck.push(cardsarr[i]);

    //==========PRINT ARRAY==========
    //printArray(cardsarr, 52);         

    //==========PRINT ARRAY FOR PLAY2==========
    //printArray(cardsarr, 52*5);     

    //==========PRINT VECTOR==========
    //for (size_t i = 0; i < 52; ++i)     //fill vector from array
    //cardsvec.push_back(cardsarr[i]);
    //printVector(cardsvec);        //print the vector

    //==========PRINT VECTOR FOR PLAY 2==========
    //for (size_t i = 0; i < 52*5; ++i)     //fill vector from array
    //cardsvec.push_back(cardsarr[i]);
    //printVector(cardsvec);        //print the vector

    //==========SCORE HAND==========
    //scoreHand(cardsvec);          //calculates the score of a hand

    //==========PLAY FUNCTION==========
    //play(deck, player, dealer);

    //==========PLAY2 FUNCTION==========
    play2(deck, player, player2, dealer);
    return 0;
}
