#include "house.h"

int main() {

	house houseOne = house(5000,"My House","123 Main Street","Anytown, FL. 33146");
	houseOne.menu_home();
}
