#include "light.h"

//constructor
light::light() {
	state = false;
}
light::light(int iD, string n){
	id=iD;
	name=n;
	state=false;
}

//setter methods  for light
void light::setId(int iD){
	id=iD;
}

void light::setName(string n){
	name=n;
}

void light::setState(bool s){
	state=s;
}

//getters
int light::getId(){
	return id;
}

string light::getName(){
	return name;
}

bool light::getState(){
	if (state==true){return true;}
	else return false;
}
