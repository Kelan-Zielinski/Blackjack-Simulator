#include "room.h"


room::room() {
	id = -1;
	name="";
	location="";
	Numlights=-1;
	NumBlinds=-1;
}

room::room(int& nextRoom_ID, string n, string l){
	id=nextRoom_ID;
	name=n;
	location=l;
	Numlights=0;
	NumBlinds=0;
	nextRoom_ID++;
}


void room::room_menu(int& next_light_id, int& next_blind_id){ // room menu implementation
	int topmenu=0;
	while(topmenu!=98){
        	cout<<"\nRoom Menu:\n"<<"\n";
        	cout<<"Room: "<<id<<", "<<name<<", "<<location<<"\n\n";
        	cout<<"1. Show status all\n";
        	cout<<"2. On.Off Light\n";
        	cout<<"3. Open/Close Blind\n";
        	cout<<"4. Raise/Lower Blind\n";
        	cout<<"5. Add Light\n";
        	cout<<"6. Add Blind\n";
        	cout<<"98. Return to Top Menu\n";
        	cout<<"99. Exit\n\n";
	cout<<"Enter a number: ";
        int input;
        cin >> input;
                if(cin.fail()){
                        cin.clear();
                        cin.ignore(99,'\n');
                        cout<<"\nINVALID SELECTION\n";
                }
                else if(input==99){
                        abort();
                }
                else if(input==98){
                        topmenu=98;
                }
		else if(input==97){
			if(!blinds.isEmpty()){
				blinds.removeValue();
				NumBlinds--;
				next_blind_id--;
			}
		}
		else if(input==96){
			if(!lights.isEmpty()){
			lights.removeValue();
			Numlights--;
			next_light_id--;
			}
		}
		else if(input==1){
			cout<<"\n";
			printRoom(cout);
		}
                else if(input==2){
			if(lights.isEmpty()){
                                cout<<"There are no lights yet.";
			}
			else{
				cout<<"\n List of lights: ";
				lightoverload(cout);
                		cout<<"Which light would you like to toggle? ";
				cin>>input;
		                if(cin.fail()){
        	                	cin.clear();
					cin.ignore(99,'\n');
                	        	cout<<"\nINVALID SELECTION\n";
                 }
				else{
					cout<<"\n";
					lights.at(input-1).setState(!lights.at(input-1).getState());
				}
			}
		}
                else if(input==3){
                        if(blinds.isEmpty()){
                                cout<<"There are no blinds yet.";
                        }
			else{
				cout<<"\n List of blinds: ";
				blindoverload(cout);
				cout<<"\n Which blind would you like to toggle?";
				cin>>input;
		                if(cin.fail()){
		                        cin.clear();
                		        cin.ignore(99,'\n');
                        		cout<<"\nINVALID SELECTION\n";
				}
				else{
					cout<<"\n";
					if(!blinds.at(input-1).blindOpenState()){
						blinds.at(input-1).setBlind('o');
					}
					else if(blinds.at(input-1).blindOpenState()){
						blinds.at(input-1).setBlind('c');
					}
        	        	}
			}
		}
		else if(input==4){
                        if(blinds.isEmpty()){
                                cout<<"There are no blinds yet.";
                        }
                        else{
                                cout<<"List of blinds: ";
                                blindoverload(cout);
                                cout<<"Which blind would you like to toggle? ";
                                cin>>input;
			                if(cin.fail()){
                        			cin.clear();
                        			cin.ignore(99,'\n');
                        			cout<<"INVALID SELECTION";
					}
				else{
					cout<<"\n";
	                	        if(!blinds.at(input-1).raiseState()){
        	                	        blinds.at(input-1).setBlind('r');
                	       		}
                        		else if(blinds.at(input-1).raiseState()){
                                		blinds.at(input-1).setBlind('l');
					}
                        	}
                	}
		}

                else if(input==5){
			addLight(next_light_id);
                } else if(input==6){addBlind(next_blind_id);}
				}
				}

void room::addLight(int& next_light_id){
	Numlights++;
	string ln;
        cout<<"Enter light name "<<next_light_id<<": ";
	getline(cin >> ws, ln);
        light temp;
        temp=light(next_light_id,ln);
        lights.addValue(temp);
        next_light_id++;
}
void room::addBlind(int& next_blind_id){
	NumBlinds++;
        string bn;
        cout<<"Enter name of blind number "<<next_blind_id<<": ";
	getline(cin >> ws, bn);
        blind temp;
        temp =blind(next_blind_id,bn);
        blinds.addValue(temp);
        next_blind_id++;}

void room::setRoomId(int i){id = i;}

void room::setRoomName(string n){name=n;}

void room::setRoomLocation(string l) {location=l;}
void room::setLightState(int i, bool s){
	if (i<1||i>Numlights){cout<<"Light Doesnt exist"<<endl;}
	else lights.at(i).setState(s);}

void room::setNumLights(int i){
	Numlights=i;}

void room::setNumBlinds (int i){
	NumBlinds=i;}

void room::setBlind (int i, char s){
	if (i<1||i>NumBlinds){cout<<"This blind does not exist"<<endl;}
	else blinds.at(i).setBlind(s);}

// all getter  methods
//methods for room
int room::getRoomId(){
	return id;
}

string room::getRoomname(){
	return name;
}

string room::getRoomlocation(){
	return location;
}
	// all functions for lights
int room::getLightId(int i){ //light id
	if (i<1||i>Numlights){cout<<"This light does not exist"<<endl;return -1;}
	else return lights.at(i).getId();}

string room::getLightName(int i){ //name of light
	if (i<1||i>Numlights){return "This light does not exist";}
	else return lights.at(i).getName();}

string  room::getLightState(int i){ //state of light
	if (i<1||i>Numlights){return "This light does not exist";}
	else if (lights.at(i).getState()==false){return "OFF";}
	else return "ON";}

int room::getNumLights(){
	return Numlights;}
int room::getBlindID(int i){
	if (i<1||i>NumBlinds){
    cout<<"This blind does not exist\n";
	return -1;}
	else return blinds.at(i).getId();
}

string room::getBlindLocation(int i){ // checks blind location
	if (i<1||i>NumBlinds){
                return "This blind does not exist\n";
	}
	else
	return blinds.at(i).getName();
}

string room::getOCState(int i){ // checks blind open/ closed
	if (i<1||i>NumBlinds){
                return "This light does not exist";
	}
	else if (blinds.at(i).blindOpenState()==false){
		return "Closed";
	}
	else
		return "Open";
}
string room::getRLState(int i){ // checks blind raised/ lowered
	if (i<1||i>NumBlinds){
                return "This light does not exist";
	}
	else
	if (blinds.at(i).raiseState()==false){
		return "Lowered";
	}
	else
		return "Raised";
}

int room::getNumBlinds(){
	return NumBlinds;
}

//print
ostream& room::lightoverload(ostream &out){
	for(int i=0;i<Numlights;i++){
		out<<i+1<<". "<<lights.at(i).getName()<<" State: "<<lights.at(i).getState();
       	}
	out<<"\n";
	return out;
}

ostream& room::blindoverload(ostream &out){
        for(int i=0;i<NumBlinds;i++){
		out<<i+1<<". "<<blinds.at(i).getName()<<" Open state: "<<blinds.at(i).blindOpenState()<<" Raised state: "<<blinds.at(i).raiseState();
       	}
       	out<<"\n";
       	return out;
}

ostream& room::printRoom(ostream &out){
	out<<""<< name <<" Id: "<<id<<" Location: "<<location;
	if(lights.isEmpty()){
		out<<"THERE ARE NO LIGHTS IN THIS ROOM.";
	//	return out;
	}
	else if(!lights.isEmpty()){
		out<<"Lights: ";
		for(int i=0;i<Numlights;i++){
			out<<lights.at(i).getName()<<" Id: "<<lights.at(i).getId()<<" State: "<<lights.at(i).getState();
		}
		out<<"\n";
	//	return out;
	}

        if(blinds.isEmpty()){
                out<<"THERE ARE NO BLINDS IN THIS ROOM.\n";
         //       return out;
        }
        else if(!blinds.isEmpty()){
		out<<"Blinds: ";
		for(int i=0;i<NumBlinds;i++){
                	out<<"\n		"<<blinds.at(i).getName()<<" Id: "<<blinds.at(i).getId()<<" Open State: "<<blinds.at(i).blindOpenState()<<" Raised State: "<<blinds.at(i).raiseState();
        	}
		out<<"\n";
	//	return out;
	}
	return out;
}
